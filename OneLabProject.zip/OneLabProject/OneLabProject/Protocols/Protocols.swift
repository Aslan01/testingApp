

import UIKit

protocol MainTabBarControllerDelegate: class {
    func updateSavedVC()
    func updateSearchVC()
}

protocol DetailViewControllerDelegate: class {
    func updateSavedData()
}

protocol SearchViewModelDelegate: class {
    func didUpdateData()
    func presentAlert(_ alert: UIAlertController)
}

protocol SettingsViewModelDelegate: class {
    func updateDataSettings()
}

protocol DetailViewModelDelegate: class {
    func appendLabels()
    func updateSavedVCData()
    func updateDataSaved()
    func presentAlert(_ alert: UIAlertController)
    func pop()
}

protocol SavedViewModelDelegate: class {
    func updateData()
}

protocol SavedViewControllerDelegate: class {
    func updateData2()
}
