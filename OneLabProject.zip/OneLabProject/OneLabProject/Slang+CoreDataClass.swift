//
//  Slang+CoreDataClass.swift
//  OneLabProject
//
//  Created by Мадияр on 7/13/19.
//  Copyright © 2019 Мадияр. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Slang)
public class Slang: NSManagedObject {

}
