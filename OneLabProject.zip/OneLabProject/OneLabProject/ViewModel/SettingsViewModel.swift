

import UIKit
import CoreData

class SettingsViewModel {
    
    weak var delegate: SettingsViewModelDelegate?

    func cleanUserDefaults() {
        Defaults.clearUserData()
        delegate?.updateDataSettings()
    }
    
    func deleteAllData(entity: String) {
        guard let managedContext = self.managedContext else { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        fetchRequest.returnsObjectsAsFaults = false
        
        do
        {
            let results = try managedContext.fetch(fetchRequest)
            for managedObject in results
            {
                let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                managedContext.delete(managedObjectData)
                delegate?.updateDataSettings()
            }
        } catch let error as NSError {
            print("Detele all data in \(entity) error : \(error) \(error.userInfo)")
        }
        
    }
    
}
