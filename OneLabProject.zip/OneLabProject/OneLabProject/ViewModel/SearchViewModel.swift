

import UIKit

class SearchViewModel {
    
    var request = AllRequests()
    weak var delegate: SearchViewModelDelegate?
    var slang: SlangModel!
    var historyData: [String] = []

    
    func numberOfElements() -> Int {
        return historyData.count
    }
    
    func getElement(at row: Int) -> String {
        let data = Array(historyData.reversed())
        return data[row]
    }
    
    func getSlang(_ slang: String) {
        request.delegate = self
        request.getSlang(slang)
    }
    
    func addHistoryData(_ str: String) {
        historyData.append(str)
        Defaults.save(historyData)
        delegate?.didUpdateData()
    }

}

extension SearchViewModel: RequestsDelegate {
    func showAlert() {
        let alert = UIAlertController(title: "Sorry", message: "Doesnt exist", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(ok)
        delegate?.presentAlert(alert)
    }
    
    func appendItems(_ slang: SlangModel) {
        historyData.append(slang.word)
        Defaults.save(historyData)
        delegate?.didUpdateData()
    }
    
    
}
