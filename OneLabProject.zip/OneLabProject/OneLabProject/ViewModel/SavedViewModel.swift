

import UIKit

class SavedViewModel {
    
    weak var delegate: SavedViewModelDelegate?
    var savedData: [Slang] = []
    var filteredData: [Slang] = []
    let detailViewModel = DetailViewModel()
    
    
    func numberOfElementsFiltered() -> Int {
        return filteredData.count
    }
    
    func getElementFiltered(at row: Int) -> Slang {
        return filteredData[row]
    }
    
    func numberOfElements() -> Int {
        return savedData.count
    }
    
    func getElement(at row: Int) -> Slang {
        return savedData[row]
    }
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        filteredData = savedData.filter({( slang : Slang) -> Bool in
            return slang.word!.lowercased().contains(searchText.lowercased())
        })
        
        delegate?.updateData()
    }

    
    func fetchSlangs() {
        guard let managedContext = self.managedContext else { return }
        
        let fetchRequest = Slang.fetchSlangRequest()
        
        do {
            self.savedData = try managedContext.fetch(fetchRequest)
            delegate?.updateData()
        } catch {
            print(error.localizedDescription)
        }
        
    }
    
}
