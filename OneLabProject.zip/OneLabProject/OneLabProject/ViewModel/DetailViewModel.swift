

import UIKit
import CoreData

class DetailViewModel {
    
    weak var delegate: DetailViewModelDelegate?
    var request = AllRequests()
    var slang: SlangModel?
    
    init() {
        request.delegate = self
    }
    
    func fetchData() -> [Slang] {
        guard let managedContext = self.managedContext else { return [] }
        
        let fetchRequest = Slang.fetchSlangRequest()
        
        do {
            return try managedContext.fetch(fetchRequest)
        } catch {
            print(error.localizedDescription)
            return []
        }
    }
    
    func getSlang(_ slang: String) {
        
        request.getSlang(slang)
        
    }
    
    func addSlang(_ sl: SlangModel) {
        guard let managedContext = self.managedContext else { return }
        
        let slang = Slang(context: managedContext)

        slang.word = sl.word
        slang.author = sl.author
        slang.definition = sl.definition
        slang.example = sl.example
        slang.isSaved = true
        
        do {
            try managedContext.save()
            delegate?.updateSavedVCData()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func addSlang(_ sl: Slang) {
        guard let managedContext = self.managedContext else { return }
        
        let slang = Slang(context: managedContext)
        
        slang.word = sl.word
        slang.author = sl.author
        slang.definition = sl.definition
        slang.example = sl.example
        slang.isSaved = true
        
        
        do {
            try managedContext.save()
            delegate?.updateSavedVCData()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func removeSlang(_ sl: Slang) {
        guard let managedContext = self.managedContext else { return }
        let fetchRequest = Slang.fetchSlangRequest()
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            for (index, _) in result.enumerated() {
                if result[index].word == sl.word {
                    managedContext.delete(result[index])
                }
            }
        } catch {
            print(error.localizedDescription)
        }
        
        do {
            try managedContext.save()
            delegate?.updateSavedVCData()
            delegate?.updateDataSaved()
        } catch {
            print(error.localizedDescription)
        }
    }
    
}

extension DetailViewModel: RequestsDelegate {
        
    func showAlert() {
        let alert = UIAlertController(title: "Sorry", message: "Doesnt exist", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default) { (action) in
            self.delegate?.pop()
        }
        alert.addAction(ok)
        delegate?.presentAlert(alert)
    }
    
    func appendItems(_ slang: SlangModel) {
        self.slang = slang
        
        delegate?.appendLabels()
    }
    
}
