//
//  DataModel.swift
//  OneLabProject
//
//  Created by Мадияр on 7/14/19.
//  Copyright © 2019 Мадияр. All rights reserved.
//

import UIKit
import CoreData

struct DataBaseManager {
    
    var managedContext: NSManagedObjectContext? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        return appDelegate.persistentContainer.viewContext
    }
    
    func addSlang(_ sl: SlangModel) {
        guard let managedContext = self.managedContext else { return }
        
        let slang = Slang(context: managedContext)
        slang.word = sl.word
        slang.author = sl.author
        slang.definition = sl.definition
        slang.example = sl.example
        
        do {
            try managedContext.save()
            fetchSlangs()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func fetchSlangs() {
        guard let managedContext = self.managedContext else {
            return
        }
        
        let fetchRequest = Slang.fetchSlangRequest()
        
        do {
//             try managedContext.fetch(fetchRequest)
        } catch {
            print(error.localizedDescription)
        }
        
    }
    
}
