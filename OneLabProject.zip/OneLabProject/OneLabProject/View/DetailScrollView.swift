

import UIKit
import SnapKit

class DetailScrollView: UIScrollView {
    
    lazy var wordLabel: UILabel = {
        let view = UILabel()
        view.font = UIFont.boldSystemFont(ofSize: 26)
        view.textColor = UIColor(red: 198/255, green: 26/255, blue: 0/255, alpha: 1.0)
        
        return view
    }()
    
    lazy var authorLabel: UILabel = {
        let view = UILabel()
        
        return view
    }()
    
    lazy var defitnitionLabel: UILabel = {
        let view = UILabel()
        view.numberOfLines = 0
        
        return view
    }()
    
    lazy var defitnitionTextLabel: UILabel = {
        let view = UILabel()
        view.text = "Definition"
        view.font = UIFont.boldSystemFont(ofSize: 26)
        
        return view
    }()
    
    lazy var exampleLabel: UILabel = {
        let view = UILabel()
        view.numberOfLines = 0
        
        return view
    }()
    
    lazy var exampleTextLabel: UILabel = {
        let view = UILabel()
        view.text = "Examples"
        view.font = UIFont.boldSystemFont(ofSize: 26)
        
        return view
    }()
    
    var contentView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    func layoutUI() {
        addSubviews([wordLabel, authorLabel, defitnitionLabel, exampleLabel, defitnitionTextLabel, exampleTextLabel])
        
        wordLabel.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview().offset(25)
        }
        defitnitionTextLabel.snp.makeConstraints { (make) in
            make.top.equalTo(wordLabel.snp.bottom).offset(10)
            make.leading.equalToSuperview().offset(25)
            make.trailing.equalToSuperview().offset(-30)
        }
        defitnitionLabel.snp.makeConstraints { (make) in
            make.top.equalTo(defitnitionTextLabel.snp.bottom).offset(10)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
        }
        exampleTextLabel.snp.makeConstraints { (make) in
            make.top.equalTo(defitnitionLabel.snp.bottom).offset(20)
            make.leading.equalToSuperview().offset(25)
            make.trailing.equalToSuperview().offset(-30)
        }
        exampleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(exampleTextLabel.snp.bottom).offset(10)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.bottom.equalToSuperview().offset(-16)
        }
        authorLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(35)
            make.trailing.equalToSuperview().offset(-30)
        }
    }
    
    func addSubviews(_ view: [UIView] ) {
        for i in view {
            contentView.addSubview(i)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
