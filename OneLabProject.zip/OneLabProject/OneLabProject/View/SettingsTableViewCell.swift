

import UIKit
import SnapKit

class SettingsTableViewCell: ThemedCell {
    
    var sectionType: SectionType? {
        didSet {
            guard let sectionType = sectionType else { return }
            textLabel?.text = sectionType.description
            switchControl.isHidden = !sectionType.containSwitch
        }
    }
    
    lazy var switchControl: UISwitch = {
        let switchControl = UISwitch()
        
        switchControl.isOn = ThemeManager.isDarkMode()
        switchControl.addTarget(self, action: #selector(handleSwitchAction), for: .valueChanged)
        
        return switchControl
    }()
    
    override func handleDarkMode(theme: Theme) {
        addSubview(switchControl)
        switchControl.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-12)
        }
        
        textLabel?.textColor = theme.textColor
        backgroundColor = theme.backgroundColor
    }
    
    @objc func handleSwitchAction(sender: UISwitch) {
        sender.isOn ? ThemeManager.enableDarkMode() : ThemeManager.disableDarkMode()
    }
}
