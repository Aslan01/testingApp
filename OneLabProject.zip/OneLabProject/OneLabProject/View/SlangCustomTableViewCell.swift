
import UIKit
import SnapKit

class SlangCustomTableViewCell: ThemedCell {
    
    lazy var titleLabel: UILabel = {
        let titleLabel = UILabel()
        
        titleLabel.font = UIFont.boldSystemFont(ofSize: 30)
        
        return titleLabel
    }()
    
    lazy var definitionLabel: UILabel = {
        let definitionLabel = UILabel()
        
        definitionLabel.numberOfLines = 4
        definitionLabel.font = UIFont.systemFont(ofSize: 16)
        
        return definitionLabel
    }()
    
    override func handleDarkMode(theme: Theme) {
        
        addSubviews([titleLabel, definitionLabel])
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
        }
        definitionLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.leading.equalToSuperview().offset(20)
            make.bottom.trailing.equalToSuperview().offset(-20)
        }
        
        backgroundColor = theme.backgroundColor
        titleLabel.textColor = theme.textColor
        definitionLabel.textColor = theme.textColor
    }
    
    func addSubviews(_ view: [UIView]) {
        for i in view {
            addSubview(i)
        }
    }
    
//    @objc func enableDarkMode() {
//        let theme = ThemeManager.currentTheme
//        
//        backgroundColor = theme.backgroundColor
//        titleLabel.textColor = theme.textColor
//        definitionLabel.textColor = theme.textColor
//    }
    
}
