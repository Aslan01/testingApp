

import UIKit
import SnapKit

class HistoryCustomTableViewCell: ThemedCell {
    
    lazy var titleLabel: UILabel = {
        let titleLabel = UILabel()
        
        titleLabel.font = UIFont.systemFont(ofSize: 20)
        
        return titleLabel
    }()

    override func handleDarkMode(theme: Theme) {
        addSubview(titleLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-10)
            make.bottom.equalToSuperview().offset(-10)
        }
        
        backgroundColor = theme.backgroundColor
        titleLabel.textColor = theme.textColor
    }
    
//    @objc func enableDarkMode() {
//        let theme = ThemeManager.currentTheme
//
//        backgroundColor = theme.backgroundColor
//        titleLabel.textColor = theme.textColor
//    }

}
