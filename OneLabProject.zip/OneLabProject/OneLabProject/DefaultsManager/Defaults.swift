

import UIKit

// Defaults Manager

class Defaults {

    static let userSessionKey = "HistoryData"
    static let isDarkModeKey = "isDarkMode"
    
    static func save(_ data: [String] ){
        UserDefaults.standard.set( data, forKey: userSessionKey)
    }
    
    static func getData()-> [String] {
        return UserDefaults.standard.array(forKey: userSessionKey) as? [String] ?? []
    }
    
    static func clearUserData(){
        UserDefaults.standard.removeObject(forKey: userSessionKey)
    }
    
    static func getDarkMode() -> Bool {
        return UserDefaults.standard.bool(forKey: isDarkModeKey)
    }
    
    static func setDarkMode(_ bool: Bool) {
        UserDefaults.standard.set(bool, forKey: isDarkModeKey)
    }
}

