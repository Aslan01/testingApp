//
//  Slangs+CoreDataClass.swift
//  
//
//  Created by Мадияр on 7/13/19.
//
//

import Foundation
import CoreData

@objc(Slangs)
public class Slangs: NSManagedObject {

}
