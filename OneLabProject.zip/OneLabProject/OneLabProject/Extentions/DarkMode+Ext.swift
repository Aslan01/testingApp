

import Foundation


extension Notification.Name {
    static let darkModeHasChanged = Notification.Name("darkModeHasChanged")
}

