//
//  Slang+CoreDataProperties.swift
//  OneLabProject
//
//  Created by Мадияр on 7/14/19.
//  Copyright © 2019 Мадияр. All rights reserved.
//
//

import Foundation
import CoreData


extension Slang {

    @nonobjc public class func fetchSlangRequest() -> NSFetchRequest<Slang> {
        return NSFetchRequest<Slang>(entityName: "Slang")
    }

    @NSManaged public var author: String?
    @NSManaged public var definition: String?
    @NSManaged public var example: String?
    @NSManaged public var word: String?

}
