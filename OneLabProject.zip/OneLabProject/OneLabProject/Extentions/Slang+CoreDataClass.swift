

import Foundation
import CoreData

@objc(Slang)
public class Slang: NSManagedObject {

}
