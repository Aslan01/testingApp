
import UIKit
import Alamofire
import SwiftyJSON

protocol RequestsDelegate: class {
    func showAlert()
    func appendItems(_ slang: SlangModel)
}

// MARK:- Request Manager

class AllRequests {
    
    weak var delegate: RequestsDelegate?
    
    func getSlang(_ slang: String) {
        let url = "http://api.urbandictionary.com/v0/define?term=\(slang)"
        
        Alamofire.request(url).responseJSON { (response) in
            switch response.result {
            case .success(let value):
                let json = JSON(value)
                if let slangs = json["list"].array, !slangs.isEmpty {                    
                    let slangg = SlangModel(json: slangs)
                    
                    self.delegate?.appendItems(slangg)
                    
                }else {
                    self.delegate?.showAlert()
                }
                
            case .failure(let value):
                print(value)
            }
        }
    }
    
}
