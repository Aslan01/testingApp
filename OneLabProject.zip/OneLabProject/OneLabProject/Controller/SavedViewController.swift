
import UIKit

class SavedViewController: ThemedController {

    let tableView = ThemedTable()
    let searchController = ThemedSearchController(searchResultsController: nil)
    let viewModel = SavedViewModel()
    let detailViewController = DetailViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        detailViewController.delegateSaved = self
        
        setupTableView()
        setupNavigationBar()
        setupSearchController()
        viewModel.fetchSlangs()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    func setupNavigationBar(){
        
        navigationItem.title = "Saved slangs"
        
    }
    
    func setupSearchController() {
        
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search slangs"
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }
    
    func setupTableView() {
        view.addSubview(tableView)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(SlangCustomTableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.tableFooterView = UIView()
        
        tableView.snp.makeConstraints { (make) in
            make.top.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
    }
    
    func searchBarIsEmpty() -> Bool {
        // Returns true if the text is empty or nil
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    func isFiltering() -> Bool {
        return searchController.isActive && !searchBarIsEmpty()
    }

}

extension SavedViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isFiltering() {
            return viewModel.numberOfElementsFiltered()
        }
        
        return viewModel.numberOfElements()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SlangCustomTableViewCell
        
        
        let slang: Slang
        
        if isFiltering() {
            slang = viewModel.getElementFiltered(at: indexPath.row)
        } else {
            slang = viewModel.getElement(at: indexPath.row)
        }
        
        cell.titleLabel.text = slang.word
        cell.definitionLabel.text = slang.definition
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let slang: Slang
        if isFiltering() {
            slang = viewModel.filteredData[indexPath.row]
        } else {
            slang = viewModel.savedData[indexPath.row]
        }
        detailViewController.savedData = slang
        detailViewController.word = slang.word
        detailViewController.isSaved = slang.isSaved
        navigationController?.pushViewController(detailViewController, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
}

extension SavedViewController: UISearchResultsUpdating {
    // MARK: - UISearchResultsUpdating Delegate
    func updateSearchResults(for searchController: UISearchController) {
        viewModel.filterContentForSearchText(searchController.searchBar.text!)
    }
}

extension SavedViewController: SavedViewModelDelegate {
    
    func updateData() {
        tableView.reloadData()
    }

}

extension SavedViewController: SavedViewControllerDelegate {
    func updateData2() {
        viewModel.fetchSlangs()
    }
    
    
}
