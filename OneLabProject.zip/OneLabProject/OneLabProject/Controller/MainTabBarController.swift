
import UIKit

class MainTabBarController: ThemedTabBar {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabBar()
        
    }
    
    func setupTabBar() {
        
        
        let savedController = createNavController(vc: SavedViewController(), selected: UIImage(named: "save")!, unselected: UIImage(named: "save")!)
        let searchVC = SearchViewController()
        searchVC.delegate = self
        let searchController = createNavController(vc: searchVC, selected: UIImage(named: "search")!, unselected: UIImage(named: "search")!)
        let settingsVC = SettingsViewController()
        settingsVC.delegate = self
        let settingsController = createNavController(vc: settingsVC, selected: UIImage(named: "settings")!, unselected: UIImage(named: "settings")!)
        
        viewControllers = [savedController, searchController, settingsController]
    
        
        guard let items = tabBar.items else { return }
        
        for item in items {
            item.imageInsets = UIEdgeInsets(top: 10, left: 0, bottom: -10, right: 0)
        }
    }

}

extension MainTabBarController {
    func createNavController(vc: UIViewController, selected: UIImage, unselected: UIImage) -> ThemedNavigation {
        let viewController = vc
        let navController = ThemedNavigation (rootViewController: viewController)
        navController.tabBarItem.image = unselected
        navController.tabBarItem.selectedImage = selected
        
        return navController
    }
}

extension MainTabBarController: MainTabBarControllerDelegate {
    func updateSavedVC() {
        guard let nvc = viewControllers?[0] as? UINavigationController, let vc = nvc.viewControllers[0] as? SavedViewController else { return }
        vc.viewModel.fetchSlangs()
    }
    
    func updateSearchVC() {
        guard let nvc = viewControllers?[1] as? UINavigationController, let vc = nvc.viewControllers[0] as? SearchViewController else { return }
        vc.viewModel.historyData = Defaults.getData()
        vc.tableView.reloadData()
    }
}

