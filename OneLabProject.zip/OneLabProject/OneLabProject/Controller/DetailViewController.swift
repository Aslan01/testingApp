
import UIKit
import SnapKit
import SVProgressHUD

class DetailViewController: ThemedController {
    
    var word: String!
    var isSaved: Bool = false
    var savedData: Slang?
    let viewModel = DetailViewModel()
    weak var delegate: DetailViewControllerDelegate?
    weak var delegateSaved: SavedViewControllerDelegate?
    let btnCustom = CheckBox()
    
    var scrollView: DetailScrollView = {
        let view = DetailScrollView()
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setupNavigationBar()
        setupScrollView()
        setupNavButton()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        let arr = viewModel.fetchData()
        var bol = false
        
        if !arr.isEmpty {
            
            for item in arr {
                if item.word?.lowercased() == self.word.lowercased() {
                    bol = true
                }
            }
        }
        
        btnCustom.isChecked = bol
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        navigationController?.navigationBar.prefersLargeTitles = false
        
        if savedData == nil {
            SVProgressHUD.show()
            viewModel.getSlang(word)
        }else {
            let slang = savedData
            
            scrollView.wordLabel.text = slang?.word
            scrollView.authorLabel.text = slang?.author
            scrollView.defitnitionLabel.text = slang?.definition
            scrollView.exampleLabel.text = slang?.example
        }
        
    }
    
    func setupNavigationBar(){
        
        navigationItem.title = "Detail"
        
    }
    
    func setupScrollView() {
        view.addSubview(scrollView)
        scrollView.snp.makeConstraints { (make) in
            make.top.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
        
        scrollView.alwaysBounceVertical = true
        
        scrollView.contentView = UIView()
        scrollView.addSubview(scrollView.contentView)
        view.sendSubviewToBack(scrollView)
        scrollView.contentView.snp.makeConstraints { (make) in
            make.edges.equalTo(scrollView)
            make.width.equalTo(scrollView)
        }
        
        scrollView.layoutUI()
        
    }
    
    func setupNavButton() {
        
        btnCustom.awakeFromNib()
        btnCustom.addTarget(self, action:#selector(buttonClicked(sender:)), for: UIControl.Event.touchUpInside)
        
        let btn = UIBarButtonItem(customView: btnCustom)
        navigationItem.rightBarButtonItem = btn
        
    }
    
    @objc func buttonClicked(sender: UIButton) {

        btnCustom.buttonClicked(sender: btnCustom)
        
        if !btnCustom.isChecked {
            if let item = savedData {
                viewModel.removeSlang(item)
            } else {
                let arr = viewModel.fetchData()
                if !arr.isEmpty {
                    var item: Slang!
                    for i in arr {
                        if i.word?.lowercased() == word.lowercased() {
                            item = i
                        }
                    }
                    viewModel.removeSlang(item)
                }
            }
            
        }else {
            if let item = viewModel.slang {
                viewModel.addSlang(item)
            }
            guard let item2 = savedData else { return }
        
            viewModel.addSlang(item2)
            
        }
        
    }
    
    override func handleDarkMode(theme: Theme) {
        
        super.handleDarkMode(theme: theme)
        scrollView.authorLabel.textColor = theme.textColor
        scrollView.exampleLabel.textColor = theme.textColor
        scrollView.defitnitionLabel.textColor = theme.textColor
        scrollView.defitnitionTextLabel.textColor = theme.textColor
        scrollView.exampleTextLabel.textColor = theme.textColor
        
    }

}

extension DetailViewController: DetailViewModelDelegate {
    
    func pop() {
        navigationController?.popToRootViewController(animated: true)
    }
    
    
    func presentAlert(_ alert: UIAlertController) {
        SVProgressHUD.dismiss()
        present(alert, animated: true)
    }
    
    
    func appendLabels() {
        let slang = viewModel.slang
        
        scrollView.wordLabel.text = slang?.word
        scrollView.authorLabel.text = slang?.author
        scrollView.defitnitionLabel.text = slang?.definition
        scrollView.exampleLabel.text = slang?.example
        
        SVProgressHUD.dismiss()
    }
    
    func updateSavedVCData() {
        
        delegate?.updateSavedData()
        delegateSaved?.updateData2()
    }
    
    func updateDataSaved() {
    
        delegateSaved?.updateData2()
    
    }
}
