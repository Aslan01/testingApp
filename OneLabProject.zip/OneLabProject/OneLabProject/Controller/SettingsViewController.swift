

import UIKit
import SnapKit

class SettingsViewController: ThemedController {
    
    let tableView = ThemedTable()
    let viewModel = SettingsViewModel()
    weak var delegate: MainTabBarControllerDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setupNavigationBar()
        setupTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    
    func setupNavigationBar(){
        
        navigationItem.title = "Settings"
        
    }
    
    func setupTableView() {
        view.addSubview(tableView)
        tableView.dataSource = self
        tableView.delegate = self
  
        tableView.register(SettingsTableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.tableFooterView = UIView()
        
        tableView.snp.makeConstraints { (make) in
            make.top.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }

    }

}

extension SettingsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return SettingsSection.allCases.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = ThemedView()
        
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        guard let section = SettingsSection(rawValue: section) else { return 0 }
        
        switch section {
        case .First: return FirstOptions.allCases.count
        case .Second: return SecondOptions.allCases.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SettingsTableViewCell
        
        guard let section = SettingsSection(rawValue: indexPath.section) else { return SettingsTableViewCell() }
        
        switch section {
        case .First:
            let first = FirstOptions(rawValue: indexPath.row)
            cell.sectionType = first
        case .Second:
            let second = SecondOptions(rawValue: indexPath.row)
            cell.sectionType = second
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let section = SettingsSection(rawValue: indexPath.section) else { return }
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        switch section {
        case .First:
            if FirstOptions(rawValue: indexPath.row)?.rawValue == 0 {
                viewModel.cleanUserDefaults()
            } else if FirstOptions(rawValue: indexPath.row)?.rawValue == 1 {
                viewModel.deleteAllData(entity: "Slang")
            }
        case .Second:
            print("")
        }
        
    }
    
}

extension SettingsViewController: SettingsViewModelDelegate {
    
    func updateDataSettings() {
        delegate?.updateSavedVC()
        delegate?.updateSearchVC()
    }
    
}
