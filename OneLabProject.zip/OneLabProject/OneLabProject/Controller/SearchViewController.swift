
import UIKit
import SnapKit
import SVProgressHUD

class SearchViewController: ThemedController {
    
    let tableView = ThemedTable()
    let searchController = ThemedSearchController(searchResultsController: nil)
    let viewModel = SearchViewModel()
    let savedViewModel = SavedViewModel()
    let detailViewController = DetailViewController()
    weak var delegate: MainTabBarControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        detailViewController.delegate = self
        
        setupTableView()
        setupNavigationBar()
        setupSearchController()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewModel.historyData = Defaults.getData()
        navigationController?.navigationBar.prefersLargeTitles = true
        SVProgressHUD.dismiss()
    }
    
    func setupNavigationBar(){
        
        navigationItem.title = "Search"
        
    }
    
    func setupSearchController() {
        
        searchController.searchBar.delegate = self
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search slangs"
        navigationItem.searchController = searchController
        definesPresentationContext = true

    }
    
    func setupTableView() {
        view.addSubview(tableView)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(HistoryCustomTableViewCell.self, forCellReuseIdentifier: "cell")
        
        tableView.tableFooterView = UIView()
        
        tableView.snp.makeConstraints { (make) in
            make.top.leading.trailing.bottom.equalTo(view.safeAreaLayoutGuide)
        }
    }

}

extension SearchViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfElements()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! HistoryCustomTableViewCell
        
        let slang = viewModel.getElement(at: indexPath.row)
        cell.titleLabel.text = slang
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        detailViewController.word = viewModel.getElement(at: indexPath.row)
        navigationController?.pushViewController(detailViewController, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }

}

extension SearchViewController: UISearchResultsUpdating, UISearchBarDelegate {

    func updateSearchResults(for searchController: UISearchController) {
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {

        let text = (searchBar.text?.lowercased())!
        if !viewModel.historyData.contains(text) {
            viewModel.addHistoryData(text)
        }
        detailViewController.word = searchBar.text?.lowercased()
        navigationController?.pushViewController(detailViewController, animated: true)
        
    }
    
}

extension SearchViewController: SearchViewModelDelegate {
    
    func presentAlert(_ alert: UIAlertController) {
        present(alert, animated: true)
    }
    
    func didUpdateData() {
        tableView.reloadData()
    }
    
}

extension SearchViewController: DetailViewControllerDelegate {
    
    func updateSavedData() {
        delegate?.updateSavedVC()
    }
    
}
