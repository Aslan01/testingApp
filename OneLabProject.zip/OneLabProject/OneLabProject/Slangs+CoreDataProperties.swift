//
//  Slangs+CoreDataProperties.swift
//  
//
//  Created by Мадияр on 7/13/19.
//
//

import Foundation
import CoreData


extension Slangs {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Slangs> {
        return NSFetchRequest<Slangs>(entityName: "Slangs")
    }

    @NSManaged public var author: String?
    @NSManaged public var definition: String?
    @NSManaged public var example: String?
    @NSManaged public var word: String?

}
