

import UIKit
import SwiftyJSON

class SlangModel {
    
    var word: String
    var definition: String
    var author: String
    var example: String
    var isSaved: Bool = false
    
    init(word: String, definition: String, author: String, example: String) {
        self.word = word
        self.definition = definition
        self.author = author
        self.example = example
    }
    
    init(json: [JSON]) {
        let item = json[0]
        self.word = item["word"].stringValue
        self.definition = item["definition"].stringValue
        self.author = item["author"].stringValue
        self.example = item["example"].stringValue
    }
    
}
