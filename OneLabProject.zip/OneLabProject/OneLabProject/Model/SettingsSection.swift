

protocol SectionType: CustomStringConvertible {
    var containSwitch: Bool { get }
}

enum SettingsSection: Int, CaseIterable, CustomStringConvertible {
    case First
    case Second
    
    var description: String {
        switch self {
        case .First: return ""
        case .Second: return ""
        }
    }
}

enum FirstOptions: Int, CaseIterable, SectionType {
    case CleanHistory
    case CleanCash
    
    var containSwitch: Bool { return false }
    
    var description: String {
        switch self {
        case .CleanHistory: return "Clean My History"
        case .CleanCash: return "Clean Cash"
        }
    }
}

enum SecondOptions: Int, CaseIterable, SectionType {
    case DarkMode
    
    var containSwitch: Bool { return true }
    
    var description: String {
        switch self {
        case .DarkMode: return "Dark Mode"
        }
    }
}
